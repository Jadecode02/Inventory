let currentView = '';

function importedS() {
    currentView = 'supplies'; 

    document.querySelector('.edit-btn').style.display = 'block';

    resetSelectDeleteButtons();

    const select = document.querySelector('.select-all');
    const dlt = document.querySelector('.delete-btn');
    if (select.classList.contains('show1')) {
        select.classList.remove('show1');
    }
    if (dlt.classList.contains('show2')) {
        dlt.classList.remove('show2');
    }

    const container = document.querySelector('.imported-clothes-container');
    const checkboxes = container.querySelectorAll('.edit-checkbox');
    checkboxes.forEach(checkbox => {
        if (checkbox.closest('.imported-supply-supply')) {
            checkbox.style.display = 'none';
        } else {
            checkbox.style.display = 'none';
        }
    });

    const items = container.querySelectorAll('.imported-clothes-item');
    items.forEach(item => item.style.display = 'none');

    const supplies = container.querySelectorAll('.imported-supply-supply');
    supplies.forEach(supply => supply.style.display = 'block');

    hideCheckboxes();

}


function importedI() {
    currentView = 'items'; 

    document.querySelector('.edit-btn').style.display = 'block';

    resetSelectDeleteButtons();
    
    const select = document.querySelector('.select-all');
    const dlt = document.querySelector('.delete-btn');
    if (select.classList.contains('show1')) {
        select.classList.remove('show1');
    }
    if (dlt.classList.contains('show2')) {
        dlt.classList.remove('show2');
    }

    const container = document.querySelector('.imported-clothes-container');
    const checkboxes = container.querySelectorAll('.edit-checkbox');
    checkboxes.forEach(checkbox => {
        if (checkbox.closest('.imported-clothes-item')) {
            checkbox.style.display = 'none';
        } else {
            checkbox.style.display = 'none';
        }
    });

    const items = container.querySelectorAll('.imported-clothes-item');
    items.forEach(item => item.style.display = 'block');

    const supplies = container.querySelectorAll('.imported-supply-supply');
    supplies.forEach(supply => supply.style.display = 'none');

    hideCheckboxes();
}

function showAll() {
    currentView = 'all'; 

    document.querySelector('.edit-btn').style.display = 'block';

    resetSelectDeleteButtons();

    const select = document.querySelector('.select-all');
    const dlt = document.querySelector('.delete-btn');
    if (select.classList.contains('show1')) {
        select.classList.remove('show1');
    }
    if (dlt.classList.contains('show2')) {
        dlt.classList.remove('show2');
    }

    const container = document.querySelector('.imported-clothes-container');
    const items = container.querySelectorAll('.imported-clothes-item');
    const supplies = container.querySelectorAll('.imported-supply-supply');

    items.forEach(item => item.style.display = 'block');
    supplies.forEach(supply => supply.style.display = 'block');
    
    const checkboxes = container.querySelectorAll('.edit-checkbox');
    checkboxes.forEach(checkbox => checkbox.style.display = 'none');

    hideCheckboxes();
}

function hideCheckboxes() {
    const container = document.querySelector('.imported-clothes-container');
    const checkboxes = container.querySelectorAll('.edit-checkbox');

    checkboxes.forEach(checkbox => {
        checkbox.classList.remove('show-checkbox');
        checkbox.checked = false; 
    });

    editMode = false;
}

function resetSelectDeleteButtons() {
    const select = document.querySelector('.select-all');
    const dlt = document.querySelector('.delete-btn');

    // Ensure select and delete buttons follow the edit mode state
    if (editMode) {
        select.classList.add('show1');
        dlt.classList.add('show2');
    } else {
        select.classList.remove('show1');
        dlt.classList.remove('show2');
    }
}

window.addEventListener('scroll', function() {
    var scrollDown = window.scrollY;
    const moveHeader = document.querySelector('.header');
    if(scrollDown > 2300 && scrollDown < 3000) {
        moveHeader.style.opacity = '1';
    } else {
        moveHeader.style.opacity = '0';
    }
});

function bckbtn() {
    const back = document.querySelector('.pay-container');
    if(back) {
        back.scrollIntoView({behavior : "smooth"});
    }
}

function searchItemsAndSupplies() {
    const searchTerm = document.querySelector('.search-item').value.toLowerCase();
    const container = document.querySelector('.imported-clothes-container');

    const clothesItems = container.querySelectorAll('.imported-clothes-item');
    const suppliesItems = container.querySelectorAll('.imported-supply-supply');

    clothesItems.forEach(item => {
        const itemName = item.querySelector('.stored-name').textContent.toLowerCase();
        if (itemName.includes(searchTerm)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });

    suppliesItems.forEach(supply => {
        const supplyName = supply.querySelector('.stored-name').textContent.toLowerCase();
        if (supplyName.includes(searchTerm)) {
            supply.style.display = 'block';
        } else {
            supply.style.display = 'none';
        }
    });
}

document.querySelector('.search').addEventListener('click', searchItemsAndSupplies);

document.querySelector('.search-item').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        searchItemsAndSupplies();
    }
});