let selectedSize = '';
let enteredQuantity = 0;
let db;

function initDB() {
    const request = indexedDB.open('InventoryDB', 3);

    request.onupgradeneeded = function(event) {
        db = event.target.result;

        if (!db.objectStoreNames.contains('items')) {
            const itemsStore = db.createObjectStore('items', { keyPath: 'id', autoIncrement: true });
            itemsStore.createIndex('name-size-price-unit', ['name', 'size', 'price', 'unit'], { unique: true });
        } else {
            const itemsStore = event.target.transaction.objectStore('items');
            if (!itemsStore.indexNames.contains('name-size-price-unit')) {
                itemsStore.createIndex('name-size-price-unit', ['name', 'size', 'price', 'unit'], { unique: true });
            }
        }

        if (!db.objectStoreNames.contains('purchases')) {
            const purchasesStore = db.createObjectStore('purchases', { keyPath: 'id', autoIncrement: true });
            purchasesStore.createIndex('date', 'date', { unique: false });
        }
    };

    request.onsuccess = function(event) {
        db = event.target.result;
        console.log('Database opened successfully.');

        listIndexes();
        loadItemsAndSupplies();
        // loadPurchases();
    };

    request.onerror = function(event) {
        console.error('Database error:', event.target.errorCode || event.target.error.name);
    };
}

document.addEventListener('DOMContentLoaded', initDB);

document.addEventListener("DOMContentLoaded", function() {
    loadItems();
    
    // Check if an item was deleted in item.html via localStorage
    const deletedItemId = localStorage.getItem('itemDeleted');
    if (deletedItemId) {
        // Remove the deleted item from the UI
        removeItemFromUI(deletedItemId);

        // Clear the itemDeleted flag from localStorage
        localStorage.removeItem('itemDeleted');
    }
});

function loadItems() {
    const request = indexedDB.open('InventoryDB', 3);
    request.onsuccess = function(event) {
        const db = event.target.result;
        const transaction = db.transaction(['items'], 'readonly');
        const store = transaction.objectStore('items');
        const getAllRequest = store.getAll();

        getAllRequest.onsuccess = function(event) {
            const items = event.target.result;
            displayItems(items);
        };

        getAllRequest.onerror = function(event) {
            console.error('Error fetching items:', event.target.error);
        };
    };
}

// function loadPurchases() {
//     const purchaseContainer = document.querySelector('.bought-container');
//     const transaction = db.transaction('purchases', 'readonly');
//     const store = transaction.objectStore('purchases');
//     const request = store.openCursor();

//     purchaseContainer.innerHTML = ''; 

//     request.onsuccess = function(event) {
//         const cursor = event.target.result;
//         if (cursor) {
//             const data = cursor.value;

//             const purchaseElement = document.createElement('div');
//             purchaseElement.classList.add('purchase-item');
//             purchaseElement.classList
//             purchaseElement.innerHTML = `
//                 <div class="item">${data.itemName}</div>
//                 <div class="item">₱${data.price}</div>
//                 <div class="item">${data.size || ''}</div>
//                 <div class="item">${data.quantity}</div>
//                 <div class="item">₱${data.totalCost}</div> 
//                 <div class="item">₱${data.budget}</div>
//                 <div class="item">₱${data.change}</div>
//                 <div class="item">${data.date}</div>
//                 <div class="item"><button class="dltBtn" onclick="deletePurchase(${data.id})">Delete</button></div>
//             `;
//             purchaseContainer.appendChild(purchaseElement);

//             cursor.continue();
//         }
//     };

//     request.onerror = function(event) {
//         console.error('Error loading purchases:', event.target.errorCode || event.target.error.name);
//     };
// }

function listIndexes() {
    if (!db) {
        console.error('Database is not initialized.');
        return;
    }

    const itemsTransaction = db.transaction(['items'], 'readonly');
    const itemsStore = itemsTransaction.objectStore('items');
    console.log('Indexes for "items" object store:');
    const itemsIndexNames = Array.from(itemsStore.indexNames);
    itemsIndexNames.forEach(index => console.log(`- ${index}`));
}

function selectSize(size, element) {
    document.querySelectorAll('.avail-size .sizes').forEach(btn => {
        btn.classList.remove('selected');
        btn.style.backgroundColor = '';
    });

    element.classList.add('selected');
    element.style.backgroundColor = 'lightblue';
    selectedSize = size;
    console.log(`Size selected for import: ${selectedSize}`);
}

let imageSrcs = []; 

function previewImages(event) {
    const files = event.target.files;
    imageSrcs = []; 

    if (files.length > 0) {
        let loadedImages = 0;
        for (const file of files) {
            const reader = new FileReader();

            reader.onload = function(event) {
                imageSrcs.push(event.target.result);
                loadedImages++;
                if (loadedImages === files.length) {
                    if (imageSrcs.length > 0) {
                        document.querySelector('.shirt-images').src = imageSrcs[0];
                    } 
                }
            };

            reader.readAsDataURL(file);
        }
    }
}

function addItem() {
    if (!db) {
        console.error('Database is not initialized.');
        return;
    }

    const formData = new FormData();
    const itemName = document.querySelector('.search-name').value.trim();
    const itemPrice = document.querySelector('.item-price').value.trim();
    const itemUnit = document.querySelector('.item-unit-input').value.trim();
    const itemQuantity = parseInt(document.querySelector('.current-quantity').value, 10) || 1;
    const itemImages = document.querySelector('.f-name').files;

    // Validate fields
    if (!itemName || !itemPrice || !selectedSize || !itemUnit || itemImages.length === 0) {
        alert('Please fill out all fields and upload at least one image.');
        return;
    }

    const priceNumber = parseFloat(itemPrice.replace(/[^0-9.]/g, '')) || 0;

    if (isNaN(priceNumber) || priceNumber <= 0) {
        alert('Please enter a valid price.');
        return;
    }

    formData.append('name', itemName);
    formData.append('size', selectedSize);
    formData.append('price', itemPrice);
    formData.append('unit', itemUnit);
    formData.append('quantity', itemQuantity);

    for (let i = 0; i < itemImages.length; i++) {
        formData.append('images', itemImages[i]);
    }

    fetch('/submit-item', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const itemData = {
                id: data.itemId,  // Use the MySQL ID from the backend
                name: itemName,
                size: selectedSize,
                price: priceNumber.toFixed(2),
                unit: itemUnit,
                type: 'item'
            };

            // Save item in IndexedDB
            const transaction = db.transaction(['items'], 'readwrite');
            const store = transaction.objectStore('items');
            const index = store.index('name-size-price-unit');
            const request = index.get([itemName, selectedSize, priceNumber.toFixed(2), itemUnit]);

            request.onsuccess = function(event) {
                const existingItem = event.target.result;

                // If the item already exists, update its quantity
                if (existingItem) {
                    // Increase the quantity by the value of itemQuantity
                    const updatedQuantity = existingItem.quantity + itemQuantity;
                    existingItem.quantity = updatedQuantity;

                    existingItem.type = 'item';
                    existingItem.id = itemData.id;  // Update with MySQL ID

                    // Save the updated item back to IndexedDB
                    const updateRequest = store.put(existingItem);
                    updateRequest.onsuccess = function() {
                        // Update the UI
                        updateRenderedItem(existingItem, existingItem); // Refresh the rendered item display
                        renderItem(existingItem); 
                        console.log('Item restocked successfully.');

                        sendToBackend(existingItem); // Send the updated item to MySQL
                    };
                    updateRequest.onerror = function(event) {
                        console.error('Update error:', event.target.errorCode || event.target.error.name);
                    };
                } else {
                    // If the item does not exist, add it as a new entry
                    const newItem = {
                        id: itemData.id, // Use the ID from the backend
                        name: itemName,
                        size: selectedSize,
                        price: priceNumber.toFixed(2),
                        unit: itemUnit,
                        imageSrcs: imageSrcs,
                        quantity: itemQuantity,
                        type: 'item'  // Add the type field to distinguish it as an item
                    };

                    const addRequest = store.add(newItem);
                    addRequest.onsuccess = function(event) {
                        newItem.id = event.target.result;  // IndexedDB-generated ID (if needed)
                        renderItem(newItem); // Render the item with the correct format
                        console.log('New item added successfully.');

                        sendToBackend(newItem); // Send to MySQL
                    };
                    addRequest.onerror = function(event) {
                        if (event.target.error.name === "ConstraintError") {
                            console.error("Error: Item with this combination already exists.");
                        } else {
                            console.error('Add error:', event.target.errorCode || event.target.error.name);
                        }
                    };
                }
            };

            request.onerror = function(event) {
                console.error('Request error:', event.target.errorCode || event.target.error.name);
            };
        } else {
            console.error('Failed to process supply:', data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function sendToBackend(item) {
    const { imageSrcs, ...itemWithoutImage } = item;  // Exclude imageSrcs

    fetch('http://localhost:3000/submit-item', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(itemWithoutImage) // Send the item excluding imageSrcs
    })
    .then(response => {
        console.log('Response status:', response.status);
        return response.text(); // Get the raw response as text (can help diagnose the issue)
    })
    .then(data => {
        // Check if the response is an error page or a success message
        if (data.startsWith('<!DOCTYPE html>')) {
            console.error('Received HTML response, something went wrong on the server:', data);
            return;
        }

        // Try parsing the response as JSON
        try {
            const jsonData = JSON.parse(data); // Try parsing the response as JSON
            if (jsonData.success) {
                console.log('Item successfully stored in MySQL:', jsonData);
            } else {
                console.error('Failed to store item in MySQL:', jsonData);
            }
        } catch (e) {
            console.error('Error parsing JSON:', e, 'Response data:', data);
        }
    })
    .catch(error => {
        console.error('Error sending item to backend:', error);
    });
}

function syncItemsToBackend() {
    const transaction = db.transaction(['items'], 'readonly');
    const store = transaction.objectStore('items');
    const request = store.getAll(); // Fetch all items

    request.onsuccess = function(event) {
        const items = event.target.result;
        items.forEach(item => {
            sendToBackend(item); // Send each item to MySQL
        });
    };

    request.onerror = function(event) {
        console.error('Error fetching items from IndexedDB:', event.target.error);
    };
}

function updateCustomUnitInput(selectElement) {
    const customUnitInput = document.getElementById('custom-unit-input');
    const selectedValue = selectElement.value;

    if (selectedValue === 'other') {
        customUnitInput.style.display = 'block'; // Show custom input field
        customUnitInput.value = ''; // Clear any existing value
        customUnitInput.focus(); // Set focus to the custom input field
    } else {
        customUnitInput.style.display = 'none'; // Hide custom input field
        customUnitInput.value = selectedValue; // Set the input field to the selected value
    }
}

function updateStockQuantity(itemId, newQuantity) {
    const container = document.querySelector('.number-clothes-stocks');
    
    if (!container) {
        console.error('Container not found.');
        return;
    }

    const itemStocked = container.querySelectorAll(`.stored-stock-item[data-item-id="${itemId}"]`);

    let updated = false;

    itemStocked.forEach(stock => {
        const stockItemId = stock.getAttribute('data-item-id');
        if (stockItemId && parseInt(stockItemId, 10) === itemId) {
            const quantityEle = stock.querySelector('.quantity'); // Ensure this class matches the HTML
            if (quantityEle) {
                quantityEle.textContent = newQuantity || 'No quantity'; // Update quantity
                updated = true;
                console.log(`Updated stock: ID ${itemId}, Quantity: ${newQuantity}`);
            } else {
                console.error('Quantity element not found.');
            }
        }
    });

    if (!updated) {
        const transaction = db.transaction(['items'], 'readonly');
        const store = transaction.objectStore('items');
        const request = store.get(itemId);

        request.onsuccess = function(event) {
            const item = event.target.result;
            if (item) {

            } else {
                console.error('Item not found in database.');
            }
        };

        request.onerror = function(event) {
            console.error('Error fetching item:', event.target.errorCode || event.target.error.name);
        };
    }
}


function initializeModal() {
    let modal = document.getElementById('imageModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'imageModal';
        modal.classList.add('modal');
        modal.innerHTML = `
            <span class="prev">&#10094;</span>
            <span class="next">&#10095;</span>
            <img class="modal-content" id="modalImg">
        `;
        document.body.appendChild(modal);
    }

    const modalImg = modal.querySelector('#modalImg');
    const prev = modal.querySelector('.prev');
    const next = modal.querySelector('.next');

    let currentImageIndex = 0;
    let currentImageSrcs = [];

    function showImageGallery(srcs) {
        currentImageSrcs = srcs;
        currentImageIndex = 0;
        if (currentImageSrcs.length > 0) {
            modalImg.src = currentImageSrcs[currentImageIndex];
            modal.style.display = 'block';
        }
    }

    function showNextImage() {
        if (currentImageSrcs.length > 0) {
            currentImageIndex = (currentImageIndex + 1) % currentImageSrcs.length;
            modalImg.src = currentImageSrcs[currentImageIndex];
        }
    }

    function showPreviousImage() {
        if (currentImageSrcs.length > 0) {
            currentImageIndex = (currentImageIndex - 1 + currentImageSrcs.length) % currentImageSrcs.length;
            modalImg.src = currentImageSrcs[currentImageIndex];
        }
    }

    prev.addEventListener('click', showPreviousImage);
    next.addEventListener('click', showNextImage);

    modal.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    return showImageGallery;
}

const showImageGallery = initializeModal();

function renderItem(item) {
    console.log('Rendering item:', item);
    const container = document.querySelector('.imported-clothes-container');

    let existingItem = container.querySelector(`.imported-clothes-item[data-item-id="${item.id}"]`);

    if (existingItem) {
        if (existingItem instanceof Element) {
            updateRenderedItem(existingItem, item);
        } else {
            console.error('Expected existingItem to be a DOM element, but got:', existingItem);
        }
    } else {
        const newItem = document.createElement('div');
        newItem.style.width = "300px";
        newItem.style.borderRadius = "20px";
        newItem.style.overflow = "hidden";
        newItem.style.position = "relative";
        newItem.style.boxShadow = "0 0 5px rgba(0,0,0,0.20)";
        newItem.style.height = "340px";
        newItem.style.backgroundColor = "white";
        newItem.classList.add('imported-clothes-item');
        newItem.setAttribute('data-item-id', item.id);

        const firstImageSrc = item.imageSrcs && item.imageSrcs.length > 0 ? item.imageSrcs[0] : '';

        newItem.innerHTML = `
            <div class="stored-img" style="position: relative;">
                <img src="${firstImageSrc}" alt="Item Image" width="100%" height="100%">
                ${item.isNew ? '<div class="new-item-design">New</div>' : ''}
            </div>
            <div class="stored-item">
                <label class="data-info">Item name:</label>
                <h2 class="stored-name">${item.name}</h2>
            </div>
            ${item.size ? `
                <div class="stored-size">
                    <label class="data-info">Size:</label>
                    <h2 class="stored-sized">${item.size}</h2>
                </div>
            ` : ''}
            <div class="stored-unit">
                <label class="data-info">Unit:</label>
                <h2 class="stored-unit-value">${item.unit}</h2>
            </div>
            <div class="stored-price">
                <label class="data-info">Price:</label>
                <h2 class="stored-name"><span class="pesos">₱</span>${parseFloat(item.price).toFixed(2)}</h2>
            </div>
            <div class="stored-quantity">
                <label class="data-info">Stocks:</label>
                <h2 class="stored-quantities">${item.quantity}</h2>
            </div>
            <div class="buy-container">
                <button class="buy-button" data-item-id="${item.id}" data-item-type="item">
                    &#128722; <!-- Shopping cart icon -->
                </button>
                <div class="quantity-input-container" style="display: none;">
                    <input type="number" class="quantity-input" placeholder="Enter quantity" min="1" />
                    <button class="confirm-quantity">Confirm</button>
                </div>
            </div>
        `;

        newItem.querySelector('.buy-button').addEventListener('click', () => {
            const id = parseInt(newItem.getAttribute('data-item-id'));
            console.log('Buy button clicked for item:', id);

            const quantityInputContainer = newItem.querySelector('.quantity-input-container');
            const quantityInput = quantityInputContainer.querySelector('.quantity-input');
            quantityInput.value = 1; // Default value
            quantityInputContainer.style.display = 'block'; // Show input container

            // Handle confirm button click
            const confirmButton = quantityInputContainer.querySelector('.confirm-quantity');
            confirmButton.onclick = () => {
                const quantity = parseInt(quantityInput.value);
                if (quantity > 0) {
                    console.log('Quantity set for checkout:', quantity);
                    
                    // Store the item and quantity for checkout later
                    itemsToCheckout.push({ itemId: id, itemType: 'item', quantity });
                    
                    // Transfer item data to the payment repository
                    transferItemDataToRepository(id, 'item', quantity);
                    
                    // Reset and hide the quantity input
                    quantityInput.value = ''; // Reset the input
                    quantityInputContainer.style.display = 'none'; // Hide the container
                } else {
                    alert('Please enter a valid quantity.');
                }
            };
            
        });
        
        newItem.querySelector('.stored-img img').addEventListener('click', () => {
            showImageGallery(item.imageSrcs);
        });

        console.log('New item created:', newItem);
        container.appendChild(newItem);
    }
}

function updateRenderedItem(existingItem, item) {
    if (!(existingItem instanceof Element)) {
        console.error('Expected existingItem to be a DOM element, but got:', existingItem);
        return;
    }

    // Update the existing item’s details
    const nameElement = existingItem.querySelector('.stored-name');
    if (nameElement) {
        nameElement.textContent = item.name;
    }

    const sizeElement = existingItem.querySelector('.stored-sized');
    if (sizeElement) {
        sizeElement.textContent = item.size || '';
    }

    const quantityElement = existingItem.querySelector('.stored-quantities');
    if (quantityElement) {
        quantityElement.textContent = item.quantity;
    }

    const imgElement = existingItem.querySelector('img');
    if (imgElement) {
        imgElement.src = item.imageSrcs && item.imageSrcs.length > 0 ? item.imageSrcs[0] : '';
    }
}


function updateItem(existingItem, item) {
    // Update the existing item with new data
    existingItem.querySelector('.stored-img img').src = item.imageSrcs[0] || '';
    existingItem.querySelector('.stored-name').textContent = item.name;
    if (item.size) {
        existingItem.querySelector('.stored-size').innerHTML = `
            <label class="data-info">Size:</label>
            <h2 class="stored-sized">${item.size}</h2>
        `;
    }
    existingItem.querySelector('.stored-price h2').innerHTML = `<span class="pesos">₱</span>${parseFloat(item.price).toFixed(2)}`;
    existingItem.querySelector('.stored-quantities').textContent = item.quantity;

    // Optionally handle new badge display if needed
    const newBadge = existingItem.querySelector('.new-badge');
    if (item.isNew) {
        if (!newBadge) {
            const badge = document.createElement('div');
            badge.className = 'new-badge';
            badge.style.position = 'absolute';
            badge.style.top = '10px';
            badge.style.right = '10px';
            badge.style.background = 'red';
            badge.style.color = 'white';
            badge.style.padding = '5px 10px';
            badge.style.borderRadius = '10px';
            badge.style.fontSize = '14px';
            badge.style.fontWeight = 'bold';
            badge.textContent = 'New';
            existingItem.querySelector('.stored-img').appendChild(badge);
        }
    } else if (newBadge) {
        newBadge.remove();
    }
}

// Select all buy buttons
const buyButtons = document.querySelectorAll('.buy-button');

buyButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Find the quantity input container associated with this button
        const quantityContainer = button.nextElementSibling; // Assuming quantity container follows the button
        
        if (quantityContainer) {
            // Toggle the visibility of the quantity input container
            if (quantityContainer.style.display === 'none') {
                quantityContainer.style.display = 'block'; // Show the container
            } else {
                quantityContainer.style.display = 'none'; // Hide the container if it's already shown
            }
        } else {
            console.error('Quantity input container not found for button:', button);
        }
    });
});

let itemsToCheckout = []; // Array to hold items and their quantities
let transferredItemsOrSuppliesArray = []

// Add event listeners for confirming the quantity
document.querySelectorAll('.confirm-quantity').forEach(confirmButton => {
    confirmButton.addEventListener('click', (event) => {
        const quantityInput = event.target.previousElementSibling; // Get the associated input

        if (quantityInput && quantityInput.value) {
            const quantity = parseInt(quantityInput.value, 10);
            const itemId = event.target.closest('.buy-container').querySelector('.buy-button').dataset.itemId;
            const itemType = event.target.closest('.buy-container').querySelector('.buy-button').dataset.itemType; // Get the item type

            // Transfer the item or supply data to the payment repository
            transferItemDataToRepository(itemId, itemType, quantity); // Transfer the data (without deducting stock)

            // Store the item and quantity for checkout later (for stock deduction)
            itemsToCheckout.push({ itemId: parseInt(itemId, 10), itemType, quantity });

            // Reset and hide the quantity input
            quantityInput.value = ''; // Reset the input
            quantityInput.parentElement.style.display = 'none'; // Hide the quantity container

            console.log('Item stored for checkout:', { itemId, itemType, quantity });
        } else {
            console.error('Quantity input not found or invalid for button:', confirmButton);
        }
    });
});

// Function to clear transferred data from the payment repository
function clearTransferredData() {
    const itemTransferredContainer = document.querySelector('.item-transferred');
    
    // Clear all child elements
    while (itemTransferredContainer.firstChild) {
        itemTransferredContainer.removeChild(itemTransferredContainer.firstChild);
    }

    // Clear total amount display
    const totalAmountInput = document.querySelector('.total-amount');
    totalAmountInput.value = ''; // Reset the total amount input

    // Clear payment amount input
    const paymentInputElement = document.querySelector('.payment-input');
    paymentInputElement.value = ''; // Reset the payment input

    // Clear change display
    const changeInput = document.querySelector('.change');
    changeInput.value = ''; // Reset the change input

    console.log('All transferred data cleared, including total, payment, and change.');
}

function insertPurchasedItemsToDatabase(items) {

    const purchaseData = items.map(item => ({
        item_id: item.itemId,
        itemname: item.itemname,
        size: item.size || '',
        price: item.price,
        unit: item.unit,
        quantity: item.quantity,
        total: item.price * item.quantity
    }));

    fetch('/submit-purchased', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ items: purchaseData}), // Send total_amount as well
    })
    .then(response => {
        return response.json();
    })
    .then(data => {
         displayPurchasedItems(data.purchasedData);
        console.log('Successfully inserted into the purchased table:', data);
        alert('Checkout completed and items added to the purchased list.');
    })
    .catch(error => {
        console.error('Error inserting purchased items:', error);
        alert('An error occurred while processing the checkout.');
    });
}

document.querySelector('.check-out-btn').addEventListener('click', () => {
    const totalCost = calculateTotalAmount();
    const currentPaymentAmount = paymentAmount;

    console.log(`Total Cost: ₱${totalCost.toFixed(2)}, Payment Amount: ₱${currentPaymentAmount.toFixed(2)}`);

    if (currentPaymentAmount === 0) {
        alert('Please enter a payment amount.');
        return;
    }

    if (transferredItemsOrSuppliesArray.length === 0) {
        alert('No items selected for checkout.');
        return;
    }

    console.log(`Comparing Payment Amount: ₱${currentPaymentAmount.toFixed(2)} with Total Cost: ₱${totalCost.toFixed(2)}`);

    if (currentPaymentAmount >= totalCost) {
        // Deduct quantities for each item in the array
        transferredItemsOrSuppliesArray.forEach((item) => {
            console.log(`Processing item ID: ${item.itemId}, Quantity: ${item.quantity}`);

            const newQuantity = item.currentQuantity - item.quantity;
            // Update UI
            updateQuantityInUI(item.itemId, item.itemType, newQuantity);

            // Send updated quantity to the backend
            buyItemOrSupply(item.itemId, item.itemType, item.quantity);

            // Optionally, send updated quantity to the backend after deduction
            sendUpdatedQuantityToBackend(item.itemId, item.itemType, newQuantity);
        });

        // Insert the purchased items into the database
        insertPurchasedItemsToDatabase(transferredItemsOrSuppliesArray);
        
        // Clear the checkout arrays after processing
        transferredItemsOrSuppliesArray.length = 0;
        clearTransferredData();

        console.log('Checkout complete and stock deducted.');
    } else {
        console.error('Insufficient payment amount.');
        alert(`Insufficient payment amount. Total cost is ₱${totalCost.toFixed(2)}. Please enter a sufficient amount.`);
    }
});

// Calculate the total amount function
function calculateTotalAmount() {
    let totalCost = 0;

    // Only consider currently visible transferred items
    const allItems = [...itemsToCheckout, ...transferredItemsOrSuppliesArray];
    
    allItems.forEach((item) => {
        const quantityInput = document.querySelector(`.item-transferred[data-id="${item.itemId}"] input`);
        if (quantityInput) {
            const updatedQuantity = parseInt(quantityInput.value, 10) || 0; // Ensure a number is used

            // Log the item details for debugging
            console.log(`Item: ${JSON.stringify(item)}, Quantity: ${updatedQuantity}`);

            // Check if price exists and is valid
            if (item.price && !isNaN(item.price)) {
                // Only add to totalCost if updatedQuantity is greater than 0
                if (updatedQuantity > 0) {
                    totalCost += item.price * updatedQuantity; // Assuming each item has a price property
                }
            } else {
                console.error(`Invalid price for item: ${item}`); // Log if price is invalid
            }
        } else {
            console.warn(`No quantity input found for item ID: ${item.itemId}`); // Warn if input is missing
        }
    });

    console.log(`Calculated Total Cost: ₱${totalCost.toFixed(2)}`); // Log the total cost for debugging
    return totalCost;
}

function buyItemOrSupply(id, type, quantity) {
    console.log('buyItem called:', { id, type, quantity });

    const mysqlId = id; // Ensure you pass the correct MySQL ID
    const storeName = 'items'; // Everything is now handled in the 'items' store
    const request = indexedDB.open('InventoryDB');

    request.onsuccess = function(event) {
        const db = event.target.result;
        const transaction = db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);
        const getRequest = store.get(id);

        getRequest.onsuccess = function(event) {
            const data = event.target.result;
            console.log('Data retrieved:', data);

            if (data) {
                // Check if there is enough stock and if quantity is valid
                if (data.quantity >= quantity && quantity > 0) {
                    data.quantity -= quantity; // Deduct the quantity
                    const updateRequest = store.put(data); // Save the updated data back to the store

                    updateRequest.onsuccess = function() {
                        console.log('Stock deducted for:', data.name);
                        updateQuantityInUI(id, type, data.quantity);
                        sendUpdatedQuantityToBackend(mysqlId, type, data.quantity);  // Ensure MySQL is updated as well
                    };

                    updateRequest.onerror = function(event) {
                        console.error('Error updating quantity:', event.target.errorCode || event.target.error.name);
                    };
                } else if (quantity === 0) {
                    console.error(`No valid quantity to deduct for ${type} with ID: ${id}`);
                } else {
                    alert(`Insufficient stock for ${type} with ID: ${id}. Available: ${data.quantity}, Requested: ${quantity}`);
                }
            } else {
                console.error(`Data not found for ${type} with ID: ${id}`);
            }
        };

        getRequest.onerror = function(event) {
            console.error('Request error:', event.target.errorCode || event.target.error.name);
        };
    };

    request.onerror = function(event) {
        console.error('Database request error:', event.target.errorCode || event.target.error.name);
    };
}

// Function to update the quantity in the UI immediately and sync with the database
function updateQuantityInUI(id, type, newQuantity) {
    // Update quantity in the main container (items or supplies)
    const mainContainer = document.querySelector('.imported-clothes-container');
    const itemClass = type === 'item' ? 'imported-clothes-item' : 'imported-supply-supply';
    const itemElement = mainContainer.querySelector(`.${itemClass}[data-item-id="${id}"]`);

    if (itemElement) {
        const quantityElement = itemElement.querySelector('.stored-quantities');
        if (quantityElement) {
            quantityElement.textContent = newQuantity;
            console.log(`Updated main container for ${type} ID: ${id}, New Quantity: ${newQuantity}`);
        } else {
            console.error('Quantity element not found in the main container item.');
        }
    } else {
        console.error(`${type} element not found in the main container for ID:`, id);
    }

    // Now send the updated quantity to the backend (database update)
    sendUpdatedQuantityToBackend(id, type, newQuantity);
}

function transferItemDataToRepository(id, type, quantity) {
    const request = indexedDB.open('InventoryDB');

    request.onsuccess = function(event) {
        const db = event.target.result;
        const storeName = 'items'; // Both 'items' and 'supplies' are in the same store
        const transaction = db.transaction([storeName], 'readonly');
        const store = transaction.objectStore(storeName);
        const getRequest = store.get(id); // Get the object by id

        getRequest.onsuccess = function(event) {
            const data = event.target.result;
            console.log(`Data retrieved for ${type}:`, data);

            if (data) {
                // Ensure the data type matches the expected type (either 'item' or 'supply')
                if (data.type !== type) {
                    console.error(`Incorrect type for ${type} with ID: ${id}`);
                    return;
                }

                // For supplies, we'll leave size and unit as empty
                const size = (type === 'item' && data.size && data.size !== '') ? data.size : ''; // Show size only for items

                const mysqlId = data.mysqlId || data.id;
                const existingIndex = transferredItemsOrSuppliesArray.findIndex(item => item.mysqlId === mysqlId);

                if (existingIndex > -1) {
                    // Update the quantity for the existing item
                    transferredItemsOrSuppliesArray[existingIndex].quantity += quantity;

                    console.log(`Updated quantity for ${type} ID: ${mysqlId}`, transferredItemsOrSuppliesArray[existingIndex]);
                } else {
                    // Add a new item to the checkout
                    transferredItemsOrSuppliesArray.push({
                        uniqueId: `${type}-${mysqlId}`,  // Unique ID based on type and mysqlId
                        itemId: data.id,  // IndexedDB item ID (if needed)
                        mysqlId: mysqlId,
                        itemname: data.name,  // MySQL ID for backend lookup
                        itemType: type,  // Type of item (e.g., 'product', 'supply', etc.)
                        price: data.price,  // Price of the item
                        quantity: quantity,  // Quantity being purchased
                        size: size,  // Size of the item (if applicable)
                        unit: data.unit,  // Unit of the item (e.g., 'kg', 'box', etc.)
                    });

                    console.log(`Added new ${type} entry to checkout:`, { id: mysqlId, price: data.price, quantity });
                }

                transferPaymentToRepository(data, quantity);
                updateTotalAmount();
            } else {
                console.error(`Data not found for ${type} with ID: ${id}`);
            }
        };

        getRequest.onerror = function(event) {
            console.error('Error fetching data:', event.target.errorCode || event.target.error.name);
        };
    };

    request.onerror = function(event) {
        console.error('Database error:', event.target.errorCode || event.target.error.name);
    };
}

function sendUpdatedQuantityToBackend(id, type, newQuantity) {
    console.log('Sending to backend:', { itemId: id, type: type, quantity: newQuantity });

    fetch('/update-item-quantity', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            itemId: id,
            itemType: type,
            quantity: newQuantity,
        }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log(`Backend successfully updated quantity for ${type} ID: ${id}`);
        } else {
            console.error(`Failed to update backend for ${type} ID: ${id}`, data);
        }
    })
    .catch(error => {
        console.error('Error updating backend:', error);
    });
}

function transferPaymentToRepository(data, quantity) {
    const itemTransferredContainer = document.querySelector('.item-transferred');
    
    // Capture the type here to ensure it's available inside the event listener.
    const type = data.type;  // This assumes 'type' is a property of 'data' object.
    
    const transferredItemDiv = document.createElement('div');
    transferredItemDiv.classList.add('transferred-item');
    transferredItemDiv.id = `ItemID-${data.id}`;
    transferredItemDiv.style.border = '1px solid pink';
    transferredItemDiv.style.height = '54px';
    transferredItemDiv.style.display = 'grid';
    transferredItemDiv.style.backgroundColor = 'rgba(255,192,203,0.50)';
    transferredItemDiv.style.color = 'black';
    transferredItemDiv.style.fontSize = '17px';
    transferredItemDiv.style.gridTemplateColumns = '1.6fr 1.0fr 0.99fr 0.72fr 1fr 1fr';
    transferredItemDiv.style.alignItems = 'center';

    const name = document.createElement('p');
    name.textContent = `${data.name}`;
    name.style.display = 'flex';
    name.style.alignItems = 'center';
    name.style.justifyContent = 'center';

    const sizeOrEmpty = document.createElement('p');
    sizeOrEmpty.textContent = data.size || ' '; // Display size if it's not empty, otherwise leave it blank
    sizeOrEmpty.style.display = 'flex';
    sizeOrEmpty.style.alignItems = 'center';
    sizeOrEmpty.style.justifyContent = 'center';
    sizeOrEmpty.style.color = 'blue';
    sizeOrEmpty.style.fontWeight = '700';

    const unit = document.createElement('p');
    unit.textContent = data.unit; // Display unit if it's not empty, otherwise leave it blank
    unit.style.display = 'flex';
    unit.style.alignItems = 'center';
    unit.style.justifyContent = 'center';

    const quantityInput = document.createElement('input');
    quantityInput.type = 'number';
    quantityInput.value = quantity;
    quantityInput.style.display = 'flex';
    quantityInput.style.alignItems = 'center';
    quantityInput.style.textAlign = 'center';
    quantityInput.style.fontSize = '22px';
    quantityInput.style.backgroundColor = 'transparent';
    quantityInput.style.border = '0';
    quantityInput.style.justifyContent = 'center';
    quantityInput.style.height = '40px';
    quantityInput.style.paddingLeft = '24px';
    quantityInput.style.outline = '0';
    quantityInput.style.width = '50px';

    const price = document.createElement('p');
    price.textContent = `₱${parseFloat(data.price).toFixed(2)}`;
    price.style.display = 'flex';
    price.style.alignItems = 'center';
    price.style.justifyContent = 'center';

    const total = document.createElement('p');
    total.textContent = `₱${(parseFloat(data.price) * quantity).toFixed(2)}`;
    total.style.display = 'flex';
    total.style.alignItems = 'center';
    total.style.justifyContent = 'center';

    // Handle quantity change and update total
    quantityInput.addEventListener('input', () => {
        const newQuantity = parseInt(quantityInput.value, 10);
        if (isNaN(newQuantity) || newQuantity <= 0) {
            console.warn('Invalid quantity entered:', quantityInput.value);
            return; // Exit early if invalid
        }
    
        const newTotal = parseFloat(data.price) * newQuantity;
        total.textContent = `₱${newTotal.toFixed(2)}`;
    
        // Update the transferred items array with new quantity
        const itemIndex = transferredItemsOrSuppliesArray.findIndex(item => item.uniqueId === `${type}-${data.id}`);
        if (itemIndex !== -1) {
            transferredItemsOrSuppliesArray[itemIndex].quantity = newQuantity;
            console.log(`Updated quantity for ${type} ID: ${data.id}:`, newQuantity);
        }
    
        updateTotalAmount(); // Update the total amount based on the new quantity
    });
    
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.style.display = 'none';

    deleteButton.addEventListener('click', (event) => {
        event.stopPropagation();
        itemTransferredContainer.removeChild(transferredItemDiv);

        // Ensure you're using `uniqueId` to find the item in the array
        const uniqueId = `${type}-${data.id}`;  // Use the captured 'type'
        const itemIndex = transferredItemsOrSuppliesArray.findIndex(item => item.uniqueId === uniqueId);
        if (itemIndex !== -1) {
            transferredItemsOrSuppliesArray.splice(itemIndex, 1);
        }

        // Update total amount after removal
        updateTotalAmount();
        console.log(`Item removed from checkout:`, data);
    });

    transferredItemDiv.addEventListener('click', (event) => {
        if (event.target !== quantityInput) {
            deleteButton.style.display = deleteButton.style.display === 'none' ? 'inline' : 'none';
        }
    });

    transferredItemDiv.appendChild(name);
    transferredItemDiv.appendChild(sizeOrEmpty);
    transferredItemDiv.appendChild(unit);
    transferredItemDiv.appendChild(quantityInput);
    transferredItemDiv.appendChild(price);
    transferredItemDiv.appendChild(total);
    transferredItemDiv.appendChild(deleteButton);

    itemTransferredContainer.appendChild(transferredItemDiv);
}

// Function to update the total amount in the checkout section
function updateTotalAmount() {
    let totalAmount = 0;
    transferredItemsOrSuppliesArray.forEach(item => {
        totalAmount += parseFloat(item.price) * item.quantity;
    });
    
    // Display the total amount in the UI (e.g., in a total amount element)
    const totalAmountElement = document.querySelector('.total-amount');
    if (totalAmountElement) {
        totalAmountElement.textContent = `₱${totalAmount.toFixed(2)}`;
    }
    
    console.log(`Updated total amount: ₱${totalAmount.toFixed(2)}`);
}


function removeFromStocksContainer(name, size) {
    const stocksContainer = document.querySelector('.number-clothes-stocks');
    const stockItems = stocksContainer.querySelectorAll('.stored-stock-item');

    stockItems.forEach(stock => {
        const itemName = stock.querySelector('.detail:first-child').textContent;
        const itemSize = stock.querySelector('.detail:nth-child(2)').textContent;
        if (itemName === name && itemSize === size) {
            stocksContainer.removeChild(stock);
        }
    });
}

function loadItemsAndSupplies() {
    const transaction = db.transaction(['items'], 'readonly');
    const store = transaction.objectStore('items');
    const request = store.getAll(); // Get all records from 'items' store

    request.onsuccess = function(event) {
        const allItemsAndSupplies = event.target.result;

        // Iterate over all records
        allItemsAndSupplies.forEach(item => {
            if (item.type === 'supply') {
                renderSupply(item);  // Call renderSupply for supplies
            } else if (item.type === 'item') {
                renderItem(item);  // Call renderItem for items
            }
        });
    };

    request.onerror = function(event) {
        console.error('Error loading items from IndexedDB:', event.target.errorCode || event.target.error.name);
    };
}

function saveSupplies(supplies) {
    supplies.forEach(supply => {
        renderSupply(supply);
        addtoSupplyStocksContainer(supply.name, supply.quantity);
    });
}

function clearInputs() {
    document.querySelector('.search-name').value = '';
    document.querySelector('.item-price').value = '';
    document.querySelector('.shirt-images').src = '';
    document.querySelector('.current-quantity').value = '';
    selectedSize = '';
    document.querySelectorAll('.sizes').forEach(button => button.style.backgroundColor = '');
}


let supplyImageSrcs = []; 

function previewImages2(event) {
    const files = event.target.files;
    supplyImageSrcs = []; 

    if (files.length > 0) {
        let loadedImages = 0;
        for (const file of files) {
            const reader = new FileReader();

            reader.onload = function(event) {
                supplyImageSrcs.push(event.target.result);
                loadedImages++;
                if (loadedImages === files.length) {
                    if (supplyImageSrcs.length > 0) {
                        document.querySelector('.supply-images').src = supplyImageSrcs[0];
                    }
                }
            };
            reader.readAsDataURL(file);
        }
    }
}

function addSupply() {
    if (!db) {
        console.error('Database is not initialized.');
        return;
    }

    const formData = new FormData();
    const supplyName = document.querySelector('.search-supply').value.trim();
    const supplyPrice = document.querySelector('.supply-price').value.trim();
    const supplyQuantityField = parseInt(document.querySelector('.c-quantity').value, 10) || 1;
    const supplyUnit = document.querySelector('.supply-unit-input').value.trim();
    const supplyImages = document.querySelector('.s-fname').files; // Assuming this is the file input field

    // Validate fields
    if (!supplyName || !supplyPrice || supplyImages.length === 0 || !supplyUnit) {
        alert('Please fill out all fields and upload at least one image.');
        return;
    }

    const convertPrice = parseFloat(supplyPrice.replace(/[^0-9.]/g, '')) || 0;

    if (isNaN(convertPrice) || convertPrice <= 0) {
        alert('Please enter a valid price.');
        return;
    }

    if (isNaN(supplyQuantityField) || supplyQuantityField <= 0) {
        alert('Please enter a valid quantity.');
        return;
    }

    // Append form data
    formData.append('name', supplyName);
    formData.append('price', convertPrice.toFixed(2));
    formData.append('unit', supplyUnit);
    formData.append('quantity', supplyQuantityField);

    // Append images to the formData
    for (let i = 0; i < supplyImages.length; i++) {
        formData.append('images', supplyImages[i]);
    }

    fetch('/submit-supply', {
        method: 'POST',
        body: formData // Use FormData instead of JSON
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Supply processed successfully:', data.itemId);

            // Update IndexedDB or re-render the supply with the new data
            const supplyData = {
                id: data.itemId,
                name: supplyName,
                price: convertPrice.toFixed(2),
                unit: supplyUnit,
                quantity: supplyQuantityField,
                size: "", // size will be null or empty
                type: 'supply'
            };

            // Update IndexedDB or re-render the supply with the new data
            updateIndexedDBOrRenderSupply(supplyData);
        } else {
            console.error('Failed to process supply:', data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function updateIndexedDBOrRenderSupply(supplyData) {
    if (!db) {
        console.error('Database not initialized.');
        return;
    }

    const transaction = db.transaction(['items'], 'readwrite');
    const store = transaction.objectStore('items');
    const index = store.index('name-size-price-unit'); // Index for both items and supplies

    // Check if the supply already exists in IndexedDB
    const request = index.get([supplyData.name, "", supplyData.price, supplyData.unit]);

    request.onsuccess = function(event) {
        const existingSupply = event.target.result;

        if (existingSupply) {
            // Supply exists, update quantity in IndexedDB
            const updatedQuantity = existingSupply.quantity + supplyData.quantity;
            existingSupply.quantity = updatedQuantity;

            // Ensure the 'type' field is 'supply'
            existingSupply.type = 'supply';

            // Use `put()` to update the existing supply
            const updateRequest = store.put(existingSupply);
            updateRequest.onsuccess = function() {
                console.log(`Supply updated in IndexedDB: ${existingSupply.name} - ${existingSupply.quantity}`);
                // Optionally, update the UI here with the new quantity
                renderSupply(existingSupply);  // Re-render supply with updated quantity
            };
            updateRequest.onerror = function(event) {
                console.error('Error updating IndexedDB:', event.target.error);
            };
        } else {
            // Supply doesn't exist, add a new supply to IndexedDB
            const newSupply = {
                id: supplyData.id, // Use a unique ID (or rely on IndexedDB's auto-increment feature)
                name: supplyData.name,
                price: supplyData.price,
                imgSrcs: supplyImageSrcs,
                quantity: supplyData.quantity,
                unit: supplyData.unit,
                size: "", // empty string for size
                type: 'supply'
            };

            // Use `add()` to insert new supply
            const addRequest = store.add(newSupply);
            addRequest.onsuccess = function(event) {
                newSupply.id = event.target.result; // Get the new supply's ID

                console.log(`New supply added to IndexedDB: ${newSupply.name} - ${newSupply.quantity}`);
               
                renderSupply(newSupply);  // Re-render supply
            };
            addRequest.onerror = function(event) {
                console.error('Error adding supply to IndexedDB:', event.target.error);
            };
        }
    };

    request.onerror = function(event) {
        console.error('Error checking supply in IndexedDB:', event.target.error);
    };
}


function updateCustomUnitInput2(selectElement) {
    const customUnitInput = document.getElementById('custom-unit-input2');
    const selectedValue = selectElement.value;

    if (selectedValue === 'other') {
        customUnitInput.style.display = 'block'; // Show custom input field
        customUnitInput.value = ''; // Clear any existing value
        customUnitInput.focus(); // Set focus to the custom input field
    } else {
        customUnitInput.style.display = 'none'; // Hide custom input field
        customUnitInput.value = selectedValue; // Set the input field to the selected value
    }
}

function renderSupply(supply) {
    console.log('Rendering supply:', supply);
    const container = document.querySelector('.imported-clothes-container');

    const existingSupply = container.querySelector(`.imported-supply-supply[data-item-id='${supply.id}']`);
    if (existingSupply) {
        container.removeChild(existingSupply);
    }

    const newSupply = document.createElement('div');
    newSupply.style.width = "300px";
    newSupply.style.borderRadius = "20px";
    newSupply.style.overflow = "hidden";
    newSupply.style.position = "relative";
    newSupply.style.boxShadow = "0 0 5px rgba(0,0,0,0.20)";
    newSupply.style.height = "340px";
    newSupply.style.backgroundColor = "white";
    newSupply.classList.add('imported-supply-supply');
    newSupply.setAttribute('data-item-id', supply.id);

    const firstImgSrc = supply.imgSrcs && supply.imgSrcs.length > 0 ? supply.imgSrcs[0] : '';
    console.log('First image src:', firstImgSrc); // Debugging line to check image source

    newSupply.innerHTML = `
        <div class="stored-img" style="position: relative;">
            <img src="${firstImgSrc}" alt="Item Image" width="100%" height="100%">
            ${supply.isNew ? '<div class="new-item-design">New</div>' : ''}
        </div>
        <div class="stored-item">
            <label class="data-info">Item name:</label>
            <h2 class="stored-name">${supply.name}</h2>
        </div>
        <div class="stored-pricee">
            <label class="data-info">Price:</label>
            <h2 class="stored-name"><span class="pesos">₱</span>${supply.price}</h2>
        </div>
        <div class="stored-unitt">
            <label class="data-info">Unit:</label>
            <h2 class="stored-unit-value">${supply.unit}</h2>
        </div>
        <div class="stored-quantityy">
            <label class="data-info">Stocks:</label>
            <h2 class="stored-quantities">${supply.quantity}</h2>
        </div>
        <div class="buy-container">
            <button class="buy-button" data-item-id="${supply.id}" data-item-type="supply">
                &#128722;
            </button>
            <div class="quantity-input-container" style="display: none;">
                <input type="number" class="quantity-input" placeholder="Enter quantity" min="1" />
                <button class="confirm-quantity">Confirm</button>
            </div>
        </div>
    `;

    newSupply.querySelector('.buy-button').addEventListener('click', () => {
        const id = parseInt(newSupply.getAttribute('data-item-id'));
        console.log('Buy button clicked for supply:', id);
        
        const quantityInputContainer = newSupply.querySelector('.quantity-input-container');
        const quantityInput = quantityInputContainer.querySelector('.quantity-input');
        quantityInput.value = 1; // Default value
        quantityInputContainer.style.display = 'block'; // Show input container

        // Handle confirm button click
        const confirmButton = quantityInputContainer.querySelector('.confirm-quantity');
        confirmButton.onclick = () => {
            const quantity = parseInt(quantityInput.value);
            if (quantity > 0) {
                console.log('Quantity set for checkout:', quantity);
                
                // Store the item and quantity for checkout later
                itemsToCheckout.push({ itemId: id, itemType: 'supply', quantity });
                
                // Transfer item data to the payment repository
                transferItemDataToRepository(id, 'supply', quantity);
                
                // Reset and hide the quantity input
                quantityInput.value = ''; // Reset the input
                quantityInputContainer.style.display = 'none'; // Hide the container
            } else {
                alert('Please enter a valid quantity.');
            }
        };        
    });

    newSupply.querySelector('.stored-img img').addEventListener('click', () => {
        showImageGallery(supply.imgSrcs);
    });

    console.log('New supply created:', newSupply);
    container.appendChild(newSupply);
}

// Function to delete an item
function deleteItem(itemId) {
    if (confirm('Are you sure you want to delete this item?')) {
        fetch(`/delete-item/${itemId}`, {
            method: 'DELETE',
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Item deleted successfully');
                
                // Remove the item from the UI
                removeItemFromUI(itemId);
                
                // Remove the item from IndexedDB
                removeItemFromIndexedDB(itemId);
                
                // Refresh the item list from the server
                fetchItems(); 
            } else {
                alert('Failed to delete the item');
            }
        })
        .catch(error => {
            console.error('Error deleting item:', error);
        });
    }
}


// Remove item from the UI
function removeItemFromUI(itemId) {
    const itemElement = document.querySelector(`.item-row[data-item-id="${itemId}"]`);
    if (itemElement) {
        itemElement.remove();
    }
}

// Remove item from IndexedDB
function removeItemFromIndexedDB(itemId) {
    const transaction = db.transaction(['items'], 'readwrite');
    const store = transaction.objectStore('items');
    const request = store.delete(itemId);

    request.onsuccess = function() {
        console.log('Item deleted from IndexedDB');
    };

    request.onerror = function(event) {
        console.error('Error deleting item from IndexedDB:', event.target.error);
    };
}
