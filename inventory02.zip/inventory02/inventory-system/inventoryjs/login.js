document.addEventListener('DOMContentLoaded', () => {
    const lgnBTN = document.querySelector('.loggin');
    const mainContainer = document.querySelector('.main-login-container');
    const logContainer = document.querySelector('.log-container');
    const inputs = document.querySelectorAll('input');

    // Only hide the login form if the user is already logged in (on page load)
    if (localStorage.getItem("loggedIn") === "true") {
        mainContainer.classList.add('hidden');  // Hide the login form if logged in
    }

    // Function to handle login and role assignment
    function lgnBtn(event) {
        event.preventDefault();  // Prevent form submission and page reload

        const userfn = document.querySelector('.input-fn').value;
        const userln = document.querySelector('.input-ln').value;
        const abiashuser = document.querySelector('.input-email').value;
        const abiashpass = document.querySelector('.input-password').value;

        // Ensure all required fields are filled
        if (!userfn || !userln || !abiashuser || !abiashpass) {
            alert('Please fill out all fields.');
            return;
        }

        // Role-based login validation
        let userRole;
        if (abiashuser === 'ownerUser' && abiashpass === 'ownerPass') {
            userRole = 'owner';  // Set role to owner
            localStorage.setItem("loggedIn", 'true'); // Mark user as logged in
            localStorage.setItem("userRole", 'owner');
            mainContainer.classList.add('hidden'); // Hide the login form after login
        } else if (abiashuser === 'staffUser' && abiashpass === 'staffPass') {
            userRole = 'staff';  // Set role to staff
            localStorage.setItem("loggedIn", 'true'); // Mark user as logged in
            localStorage.setItem("userRole", 'staff');
        } else if (abiashuser === 'adminUser' && abiashpass === 'adminPass') {
            userRole = 'admin';  // Set role to admin
            localStorage.setItem("userRole", 'admin');
        } else {
            alert('Incorrect username or password');
            return;
        }

        applyRolePermissions(userRole);

        // Mock backend call to save login data (optional)
        fetch('/submitdata-form', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                userfirstname: userfn,
                userlastname: userln,
                abiashusername: abiashuser,
                abiashpassword: abiashpass,
                role: userRole  // Pass the role based on the login type
            }),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text();
        })
        .then(data => {
            alert(data);  // Show the response from the backend
            inputs.forEach(input => input.value = ''); // Clear fields after login

            // Redirect after successful submission
            if (userRole === 'admin') {
                window.location.href = '/item';  // Redirect only after data is successfully inserted
            } else {
                window.location.href = '/inventory';  // Redirect for other roles
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('There was an error processing your request. Please try again later.');
            // Optionally, you can clear the fields here if you want after a failed login attempt
            inputs.forEach(input => input.value = ''); 
        });
    }

    function applyRolePermissions(role) {
        // Show or hide elements based on the role
        if (role === 'owner') {
            document.querySelectorAll('.owner-only').forEach(el => el.style.display = 'block');
            document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'block');
            document.querySelectorAll('.staff-access').forEach(el => el.style.display = 'block');
            document.querySelectorAll('.public-access').forEach(el => el.style.display = 'block');
        } else if (role === 'staff') {
            document.querySelectorAll('.staff-access').forEach(el => el.style.display = 'block');
            document.querySelectorAll('.public-access').forEach(el => el.style.display = 'block');
            document.querySelectorAll('.owner-only').forEach(el => el.style.display = 'none');
            document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'none');
        } else if (role === 'admin') {
            document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'block');
            document.querySelectorAll('.public-access').forEach(el => el.style.display = 'block');
            document.querySelectorAll('.owner-only').forEach(el => el.style.display = 'none');
            document.querySelectorAll('.staff-access').forEach(el => el.style.display = 'none');
        }

        const buttons = document.querySelectorAll('button[data-role]');
        buttons.forEach(button => {
            const allowedRoles = button.getAttribute('data-role').split(',');

            // If the user's role is not allowed, disable the button
            if (!allowedRoles.includes(role)) {
                button.setAttribute('disabled', 'true');
                button.style.pointerEvents = 'none';  // Prevent clicking
                button.style.opacity = '0.5';         // Visual cue that the button is disabled
            } else {
                button.removeAttribute('disabled');
                button.style.pointerEvents = 'auto';  // Enable clicking
                button.style.opacity = '1';           // Reset opacity
            }
        });
    }

    // Attach event listener to the login button
    lgnBTN.addEventListener('click', lgnBtn);

    // Clear inputs on load
    inputs.forEach(input => input.value = '');

    // Check if user is logged in as owner and show the admin button
    const userRole = localStorage.getItem("userRole");
    const adminButton = document.querySelector('.admin-btn');

    // Only show the admin button if the user is logged in as an "owner"
    if (userRole === 'owner') {
        adminButton.style.display = 'flex';
    } else {
        adminButton.style.display = 'none';
    }

    // Logout function
    window.logout = function() {
        if (confirm("Are you sure you want to log out?")) {
            logContainer.classList.remove('movelog');
            mainContainer.classList.remove('remove');
            localStorage.removeItem("loggedIn");
            localStorage.removeItem("userRole"); // Clear the user role on logout
            inputs.forEach(input => input.value = '');
            window.location.reload(); // Optionally reload the page on logout to reset everything
        }
    };
});
