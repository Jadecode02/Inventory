document.addEventListener('DOMContentLoaded', () => {
    const costInput = document.querySelector('.cost-p');
    const markupInput = document.querySelector('.markup');
    const priceInput = document.querySelector('.price02');
    const submitButton = document.querySelector('.submit-newp');

    function updatePrice() {
        const cost = parseFloat(costInput.value.trim()) || 0;
        const markup = parseFloat(markupInput.value.trim()) || 0;
        const finalPrice = cost + (cost * markup / 100);
        priceInput.value = finalPrice.toFixed(2);
    }

    costInput.addEventListener('input', updatePrice);
    markupInput.addEventListener('input', updatePrice);

    function addNewP(event) {
        event.preventDefault(); 

        const itemName = document.querySelector('.input-discription').value.trim();
        const itemDateReceived = document.querySelector('.data01').value.trim();
        const itemQuantityReceived = parseInt(document.querySelector('.quantity01').value, 10) || 0;
        const itemCost = parseFloat(document.querySelector('.cost-p').value.trim()) || 0;
        const itemDateSold = document.querySelector('.data02').value.trim();
        const itemInvNo = document.querySelector('.inv-num').value.trim();
        const itemAddress = document.querySelector('.p-address').value.trim();
        const itemQuantitySold = parseInt(document.querySelector('.quantity02').value, 10) || 0;
        const itemPrice = parseFloat(document.querySelector('.price02').value.trim()) || 0;
        const itemAmount = parseFloat(document.querySelector('.amount02').value.trim()) || 0;
        const stocksOnHand = document.querySelector('.hold').value.trim();

        if (!itemDateReceived || !itemQuantityReceived || !itemCost || !itemDateSold || !itemInvNo || !itemAddress || !itemQuantitySold || !itemPrice || !itemAmount || !stocksOnHand) {
            alert('Please fill out all fields.');
            return; 
        }

        fetch('/submit-form', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                description: itemName,
                date1: itemDateReceived,
                quantity1: itemQuantityReceived,
                cost: itemCost,
                date2: itemDateSold,
                invNum: itemInvNo,
                pAddress: itemAddress,
                quantity2: itemQuantitySold,
                price: itemPrice.toFixed(2),
                amount: itemAmount,
                hold: stocksOnHand,
            }),
        })
        .then(response => response.text())
        .then(data => {
            alert(data); 
            document.querySelectorAll('input').forEach(input => input.value = '');
            fetchProducts(); 
        })
        .catch(error => console.error('Error:', error));
    }

    submitButton.addEventListener('click', addNewP);

    fetchProducts(); 
});


let currentProductData = {};
let useServer = true; 

function fetchProducts() {
    if (useServer) {
        fetch('/get-products')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Fetched data from server:', data);
                currentProductData = {};
                const container = document.querySelector('.newproduct-output');
                container.innerHTML = '';

                data.forEach(product => {
                    currentProductData[product.id] = { ...product };
                    const row = document.createElement('div');
                    row.className = 'output-row';
                    row.dataset.id = product.id;

                    Object.keys(product).forEach(key => {
                        if (key !== 'description') {
                            const cell = document.createElement('div');
                            cell.className = 'output-cell';
                            cell.classList.add('cell');
                            cell.textContent = key === 'date1' || key === 'date2'
                                ? new Date(product[key]).toISOString().split('T')[0]
                                : product[key];

                            cell.dataset.key = key;
                            cell.contentEditable = false;

                            cell.addEventListener('dblclick', () => enableEditing(cell));
                            cell.addEventListener('blur', () => disableEditing(cell));
                            cell.addEventListener('keydown', (event) => {
                                if (event.key === 'Enter') {
                                    event.preventDefault();
                                    disableEditing(cell);
                                }
                            });

                            row.appendChild(cell);
                        }
                    });

                    const importCell = document.createElement('div');
                    importCell.className = 'output-cell';
                    const importButton = document.createElement('button');
                    importButton.textContent = 'Import';
                    importButton.addEventListener('click', () => showImportForm(product));
                    importCell.appendChild(importButton);
                    row.appendChild(importCell);

                    const deleteCell = document.createElement('div');
                    deleteCell.className = 'output-cell';
                    const deleteButton = document.createElement('button');
                    deleteButton.textContent = 'Delete';
                    deleteButton.setAttribute('data-role', 'owner');  // Only owners should be able to delete
                    deleteButton.addEventListener('click', () => deleteProduct(product.id));
                    deleteCell.appendChild(deleteButton);
                    row.appendChild(deleteCell);


                    container.appendChild(row);
                });
            })
            .catch(error => {
                console.error('Error fetching from server:', error);
                alert('Failed to load products from server.');
            });
    } else {
        if (!db) {
            console.error('Database is not initialized.');
            return;
        }

        const transaction = db.transaction(['items'], 'readonly');
        const store = transaction.objectStore('items');
        const request = store.getAll();

        request.onsuccess = function(event) {
            const data = event.target.result;
            console.log('Fetched data from IndexedDB:', data);

            const container = document.querySelector('.imported-clothes-container');
            container.innerHTML = '';

            data.forEach(item => {
                if (item.isSupply || !item.size.trim()) {
                    renderSupply(item);
                } else {
                    renderItem(item);
                }
            });
        };

        request.onerror = function(event) {
            console.error('Fetch error from IndexedDB:', event.target.errorCode || event.target.error.name);
        };
    }
}

function previewImages3() {
    const imageInput = document.getElementById('item-images');
    const previewContainer = document.querySelector('.image-preview-container');

    if (imageInput.files && imageInput.files.length > 0) {
        previewContainer.innerHTML = ''; // Clear previous previews

        // Show only the first image in the preview
        const firstFile = imageInput.files[0];
        const reader = new FileReader();

        reader.onload = function(e) {
            const imgElement = document.createElement('img');
            imgElement.src = e.target.result;
            imgElement.style.width = '100%';
            imgElement.style.height = '100%';
            previewContainer.appendChild(imgElement);
        };

        reader.onerror = function() {
            console.error('Error reading file:', firstFile.name);
        };

        reader.readAsDataURL(firstFile); // Start reading the first file
    } else {
        previewContainer.innerHTML = ''; // Clear previews if no files
    }
}

function showImportForm(product) {
    const formHtml = `
        <div id="import-form-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 8; display: flex; justify-content: center; align-items: center;">
            <div class="newpnewform" style="padding: 20px; border-radius: 10px; background: #fff;">
                <h2>Import Item</h2>
                <form id="import-form">
                    <div class="image-preview-container"></div>
                    <div class="onenewp">
                        <div class="newpfirst">
                            <label for="item-name">Name:</label>
                            <input type="text" id="item-name" name="name" required>
                        </div>
                        <div class="newpsecond">
                            <label for="item-size">Size:</label>
                            <input type="text" id="item-size" name="size">
                        </div>
                    </div>
                    <div class="secondnewp">
                        <div class="newpthird">
                            <label for="item-quantity">Quantity:</label>
                            <input type="number" id="item-quantity" name="quantity" required>
                        </div>
                        <div class="newpfifth">
                            <label for="item-price">Price:</label>
                            <input type="text" id="item-price" name="price" readonly>
                        </div>
                    </div>
                    <div class="newpfourth">
                        <label for="item-images">Images:</label>
                        <input type="file" id="item-images" name="images" accept="image/*" multiple required>
                    </div>
                    <div class="newpunit">
                        <label for="import-unit-select">Unit:</label>
                        <div class="unit-selector">
                            <select id="import-unit-select" onchange="toggleCustomUnitInput(this)">
                                <option value="">Select a unit</option>
                                <option value="pieces">Pieces</option>
                                <option value="boxes">Boxes</option>
                                <option value="packs">Packs</option>
                                <option value="sets">Sets</option>
                                <option value="other">Other (specify)</option>
                            </select>
                            <input type="text" id="import-custom-unit" placeholder="Enter custom unit" style="display:none;">
                        </div>
                    </div>
                    <div class="newp-btns">
                        <button class="newpsubmit" type="submit">Add Item</button>
                        <button class="newpcancel" type="button" id="cancel-import">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    `;

    document.body.insertAdjacentHTML('beforeend', formHtml);

    const priceInput = document.getElementById('item-price');
    priceInput.value = product.price;

    const imageInput = document.getElementById('item-images');
    const previewContainer = document.querySelector('.image-preview-container');
    imageInput.addEventListener('change', previewImages3);

    const importForm = document.getElementById('import-form');
    const cancelImport = document.getElementById('cancel-import');

    importForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const itemSize = document.getElementById('item-size').value.trim();

        if (itemSize) {
            handleImportSubmit();  // Size field is filled
        } else {
            handleWithoutSize();   // Size field is not filled
        }
    });

    cancelImport.addEventListener('click', () => {
        document.getElementById('import-form-overlay').remove();
    });
}

function toggleCustomUnitInput(selectElement) {
    const customUnitInput = document.getElementById('import-custom-unit');
    if (selectElement.value === 'other') {
        customUnitInput.style.display = 'block';
    } else {
        customUnitInput.style.display = 'none';
    }
}

function checkIfItemExists(name, size, price, unit) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(['items'], 'readonly');
        const store = transaction.objectStore('items');
        const index = store.index('name-size-price-unit');
        const request = index.get([name, size, price, unit]);

        request.onsuccess = function(event) {
            if (event.target.result) {
                resolve(true);  // Item exists
            } else {
                resolve(false);  // Item doesn't exist
            }
        };

        request.onerror = function(event) {
            reject(event.target.error);
        };
    });
}

function handleImportSubmit() {
    const itemName = document.getElementById('item-name').value.trim();
    const itemSize = document.getElementById('item-size').value.trim() || 'N/A';
    const itemQuantity = parseInt(document.getElementById('item-quantity').value, 10) || 1;
    const itemPrice = document.getElementById('item-price').value.trim();
    const unitSelect = document.getElementById('import-unit-select').value;
    const customUnit = document.getElementById('import-custom-unit').value.trim();
    const finalUnit = unitSelect === 'other' ? customUnit : unitSelect;
    const imageFiles = document.getElementById('item-images').files;

    const formData = new FormData();

    // Check for required fields
    if (!itemName || !itemPrice || !finalUnit || imageFiles.length === 0) {
        alert('Please fill out all fields, select a unit, and upload at least one image.');
        return;
    }

    const priceNumber = parseFloat(itemPrice.replace(/[^0-9.]/g, ''));
    if (isNaN(priceNumber) || priceNumber <= 0) {
        alert('Please enter a valid price.');
        return;
    }

    // Append data to FormData
    formData.append('name', itemName);
    formData.append('size', itemSize);  // May want to handle empty size if needed
    formData.append('price', priceNumber.toFixed(2));
    formData.append('unit', finalUnit);
    formData.append('quantity', itemQuantity);

    // Append images
    for (let i = 0; i < imageFiles.length; i++) {
        formData.append('images', imageFiles[i]);
    }

    // Check if the item already exists in IndexedDB
    checkIfItemExists(itemName, itemSize, priceNumber.toFixed(2), finalUnit).then(exists => {
        if (exists) {
            // If the item exists in IndexedDB, get it and update the quantity
            const transaction = db.transaction(['items'], 'readwrite');
            const store = transaction.objectStore('items');
            const index = store.index('name-size-price-unit');
            const request = index.get([itemName, itemSize, priceNumber.toFixed(2), finalUnit]);

            request.onsuccess = function(event) {
                const existingItem = event.target.result;
                if (existingItem) {
                    // Update the quantity of the existing item
                    const updatedQuantity = Number(existingItem.quantity) + Number(itemQuantity);
                    existingItem.quantity = updatedQuantity;

                    // Put the updated item back into the store (update IndexedDB)
                    const updateRequest = store.put(existingItem);
                    updateRequest.onsuccess = function() {
                        alert('Item quantity updated successfully!');
                        renderItem(existingItem);  // Re-render the updated item
                    };
                    updateRequest.onerror = function(event) {
                        console.error('Error updating item:', event.target.error);
                        alert('An error occurred while updating the item.');
                    };

                    // Append the existing item id to formData for the backend
                    formData.append('id', existingItem.id);
                } else {
                    alert('The item no longer exists in the database.');
                }
            };

            request.onerror = function(event) {
                console.error('Error checking existing item:', event.target.error);
                alert('An error occurred while checking if the item exists.');
            };
        } else {
            // Item doesn't exist, create a new one
            convertImagesToBase64(imageFiles).then(imageSrcs => {
                const newItem = {
                    name: itemName,
                    size: itemSize,
                    price: priceNumber.toFixed(2),
                    unit: finalUnit,
                    imageSrcs: imageSrcs,
                    quantity: itemQuantity,
                    type: 'item',
                    isNew: true
                };

                const transaction = db.transaction(['items'], 'readwrite');
                const store = transaction.objectStore('items');
                const addRequest = store.add(newItem);

                addRequest.onsuccess = function(event) {
                    newItem.id = event.target.result;
                    renderItem(newItem); 
                    alert('Item added successfully!');
                };

                addRequest.onerror = function(event) {
                    const error = event.target.error;
                    if (error.name === 'ConstraintError') {
                        alert('An item with the same name, size, price, and unit already exists.');
                    } else {
                        console.error('Add error:', error.name || error.message);
                        alert('An error occurred while adding the item.');
                    }
                };

                document.getElementById('import-form-overlay').remove();
            }).catch(error => {
                console.error('Error converting images:', error);
                alert('An error occurred while processing the images.');
            });
        }

        // Send the request to the backend (whether the item is new or updated)
        fetch('/submit-item', {
            method: 'POST',
            body: formData,  // Send FormData to handle images
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Item added or updated successfully!');
            } else {
                alert('Failed to add or update item');
            }
        })
        .catch(error => {
            console.error('Error submitting item:', error);
            alert('An error occurred while adding the item.');
        });

    }).catch(error => {
        console.error('Error checking if item exists:', error);
        alert('An error occurred while checking for duplicates.');
    });
}

function convertImagesToBase64(files) {
    return new Promise((resolve, reject) => {
        const imageSrcs = [];
        let processed = 0;

        Array.from(files).forEach(file => {
            const reader = new FileReader();

            reader.onload = function(e) {
                imageSrcs.push(e.target.result);
                processed++;

                if (processed === files.length) {
                    resolve(imageSrcs);
                }
            };

            reader.onerror = function() {
                reject(new Error("Failed to convert image to base64."));
            };

            // Start reading the file
            reader.readAsDataURL(file);
        });
    });
}

function convertSupplyImagesToBase64(files) {
    return new Promise((resolve, reject) => {
        const imgSrcs = [];
        let processed = 0;

        Array.from(files).forEach(file => {
            const reader = new FileReader();

            reader.onload = function(e) {
                imgSrcs.push(e.target.result);
                processed++;

                if (processed === files.length) {
                    resolve(imgSrcs);
                }
            };

            reader.onerror = function() {
                reject(new Error("Failed to convert image to base64."));
            };

            // Start reading the file
            reader.readAsDataURL(file);
        });
    });
}

function checkIfItemOrSupplyExists(name, price, unit, type) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(['items'], 'readonly');
        const store = transaction.objectStore('items');
        const index = store.index('name-size-price-unit');  // Assuming the same index

        // Query for supplies with an empty string as the size
        const keyRange = IDBKeyRange.bound([name, "", price, unit], [name, "", price, unit]);

        const request = index.openCursor(keyRange); // Open a cursor with the key range

        request.onsuccess = function(event) {
            const cursor = event.target.result;

            if (cursor) {
                const existingItemOrSupply = cursor.value;
                if (existingItemOrSupply.type === type) {
                    resolve(existingItemOrSupply); // Found matching supply/item of the correct type
                } else {
                    resolve(null); // Found but it's of a different type
                }
            } else {
                resolve(null); // No match found
            }
        };

        request.onerror = function(event) {
            reject(event.target.error);
        };
    });
}

function handleWithoutSize() {
    const supplyName = document.getElementById('item-name').value.trim();
    const supplyPrice = document.getElementById('item-price').value.trim();
    const supplyQuantity = parseInt(document.getElementById('item-quantity').value, 10) || 1;
    const imageInput = document.getElementById('item-images');

    // Unit selection
    const unitSelect = document.getElementById('import-unit-select').value;
    const customUnit = document.getElementById('import-custom-unit').value.trim();
    const finalUnit = unitSelect === 'other' ? customUnit : unitSelect;

    // Validate fields and unit selection
    if (!supplyName || !supplyPrice || !finalUnit || !imageInput || !imageInput.files || imageInput.files.length === 0) {
        alert('Please fill out all fields, select a unit, and upload at least one image.');
        return;
    }

    const supplyPriceNumber = parseFloat(supplyPrice.replace(/[^0-9.]/g, ''));
    if (isNaN(supplyPriceNumber) || supplyPriceNumber <= 0) {
        alert('Please enter a valid price.');
        return;
    }

    // Create FormData object
    const formData = new FormData();
    formData.append('name', supplyName);
    formData.append('size', '');  // Empty size for supplies without size
    formData.append('price', supplyPriceNumber.toFixed(2));
    formData.append('unit', finalUnit);
    formData.append('quantity', supplyQuantity);

    // Add images to formData
    if (imageInput.files.length > 0) {
        for (let i = 0; i < imageInput.files.length; i++) {
            formData.append('images', imageInput.files[i]); // Append images to formData
        }
    }

    // Process the images and convert to Base64 for frontend usage
    convertSupplyImagesToBase64(imageInput.files).then(supplyImgSrcs => {
        formData.append('imgSrcs', JSON.stringify(supplyImgSrcs)); // Append base64 images

        // Check if the supply already exists
        checkIfItemExists(supplyName, '', supplyPriceNumber.toFixed(2), finalUnit).then(itemExists => {
            if (itemExists) {
                // If the supply already exists, get it from IndexedDB and update the quantity
                const transaction = db.transaction(['items'], 'readwrite');
                const store = transaction.objectStore('items');
                const index = store.index('name-size-price-unit');
                const request = index.get([supplyName, '', supplyPriceNumber.toFixed(2), finalUnit]);

                request.onsuccess = function(event) {
                    const existingSupply = event.target.result;
                    if (existingSupply) {
                        // Update the quantity of the existing supply
                        const updatedQuantity = Number(existingSupply.quantity) + Number(supplyQuantity);
                        existingSupply.quantity = updatedQuantity;

                        // Put the updated supply back into the store (update IndexedDB)
                        const updateRequest = store.put(existingSupply);
                        updateRequest.onsuccess = function() {
                            alert('Supply quantity updated successfully!');
                            renderSupply(existingSupply);  // Re-render the updated supply
                        };
                        updateRequest.onerror = function(event) {
                            console.error('Error updating supply:', event.target.error);
                            alert('An error occurred while updating the supply.');
                        };
                    } else {
                        alert('The supply no longer exists in the database.');
                    }
                };

                request.onerror = function(event) {
                    console.error('Error checking existing supply:', event.target.error);
                    alert('An error occurred while checking if the supply exists.');
                };

                // Stop execution here to prevent adding a new supply
                return;
            }

            const newSupply = {
                name: supplyName,
                size: "",  // Empty size for supplies without size
                price: supplyPriceNumber.toFixed(2),
                imgSrcs: supplyImgSrcs,  // Base64 images for frontend display
                quantity: supplyQuantity,
                unit: finalUnit,
                type: 'supply',  // Mark it as a supply
                isNew: true
            };

            const transaction = db.transaction(['items'], 'readwrite');
            const store = transaction.objectStore('items');
            const addRequest = store.add(newSupply);

            addRequest.onsuccess = function(event) {
                newSupply.id = event.target.result; // Get the ID from the transaction
                renderSupply(newSupply);  // Render the new supply
                alert('Supply added successfully!');
                document.getElementById('import-form-overlay').remove();
            };

            addRequest.onerror = function(event) {
                console.error('Add error:', event.target.error);
                alert('An error occurred while adding the supply.');
            };
        }).catch(error => {
            console.error('Error checking if supply exists:', error);
            alert('An error occurred while checking if the supply exists.');
        });
    }).catch(error => {
        console.error('Error converting images:', error);
        alert('An error occurred while processing the images.');
    });

    fetch('/submit-supply', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Supply added or updated successfully on the backend!');
        } else {
            alert('Failed to add or update supply on the backend.');
        }
    })
    .catch(error => {
        console.error('Error submitting supply:', error);
        alert('An error occurred while submitting the supply to the backend.');
    });
}

function enableEditing(cell) {
    cell.contentEditable = 'true';
    cell.focus(); 
}

function disableEditing(cell) {
    const row = cell.parentElement;
    const id = row.dataset.id;
    const key = cell.dataset.key;
    const value = cell.textContent.trim();

    cell.contentEditable = 'false';

    if (cell.dataset.originalValue !== value) {
        saveChanges(id, key, value);
    }
}

document.addEventListener('focusin', (event) => {
    if (event.target.classList.contains('output-cell')) {
        event.target.dataset.originalValue = event.target.textContent.trim();
    }
});


function saveChanges(id, key, value) {
    if (key === 'date1' || key === 'date2') {
        const formattedDate = new Date(value).toISOString().split('T')[0];
        value = formattedDate;
    }

    currentProductData[id][key] = value; // Update local data

    fetch(`/edit-product/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(currentProductData[id]), // Send entire product data
    })
    .then(response => response.text())
    .then(message => {
        alert(message);
        fetchProducts(); 
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to update product.');
    });
}

function deleteProduct(id) {
    fetch(`/delete-product/${id}`, { method: 'DELETE' })
        .then(response => response.text())
        .then(message => {
            alert(message);
            fetchProducts(); 
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to delete product.');
        });
}

function editProduct(id) {
    const newDescription = prompt('Enter new description:');
    if (newDescription === null) return;

    const newDate1 = prompt('Enter new date1 (YYYY-MM-DD):');
    const newDate2 = prompt('Enter new date2 (YYYY-MM-DD):');
    const newQuantity1 = parseInt(prompt('Enter new quantity1:'), 10);
    const newCost = parseFloat(prompt('Enter new cost:'));
    const newQuantity2 = parseInt(prompt('Enter new quantity2:'), 10);
    const newPrice = parseFloat(prompt('Enter new price:'));
    const newAmount = parseFloat(prompt('Enter new amount:'));
    const newHold = prompt('Enter new hold:');
    const newInvNum = prompt('Enter new invNum:');
    const newPAddress = prompt('Enter new pAddress:');

    const updatedProduct = {
        description: newDescription,
        date1: newDate1,
        quantity1: newQuantity1,
        cost: newCost,
        date2: newDate2,
        invNum: newInvNum,
        pAddress: newPAddress,
        quantity2: newQuantity2,
        price: newPrice,
        amount: newAmount,
        hold: newHold
    };

    fetch(`/edit-product/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedProduct),
    })
    .then(response => response.text())
    .then(message => {
        alert(message);
        fetchProducts(); 
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to update product.');
    });
}