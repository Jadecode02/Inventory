let totalAmount = 0;
let paymentAmount = 0;

// Function to update the total amount display
function updateTotalAmountDisplay() {
    const totalAmountInput = document.querySelector('.total-amount');
    totalAmountInput.value = `₱${totalAmount.toFixed(2)}`; // Format total to 2 decimal places
}

// Function to update change display
function updateChangeDisplay() {
    const changeInput = document.querySelector('.change');
    const change = paymentAmount - totalAmount; // Calculate change

    // Display change or 0 if negative, formatting to 2 decimal places
    changeInput.value = `₱${change >= 0 ? change.toFixed(2) : '0.00'}`;
}

// Function to update the total amount based on all transferred items
function updateTotalAmount() {
    totalAmount = 0; // Reset total amount
    const transferredItems = document.querySelectorAll('.transferred-item');

    transferredItems.forEach(item => {
        const quantityInput = item.querySelector('input[type="number"]');
        const priceText = item.querySelector('p:nth-child(5)').textContent; // Price element
        const quantity = parseInt(quantityInput.value, 10) || 0; // Current quantity
        
        // Debugging: Log each item's price and quantity
        console.log(`Price Text: ${priceText}, Quantity: ${quantity}`);
        
        const price = parseFloat(priceText.replace('₱', '').replace(',', '').trim()); // Parse price from text
        
        // If price is not a number, log an error
        if (isNaN(price) || price < 0) {
            console.error(`Invalid price for item: ${item}`);
        } else {
            totalAmount += price * quantity; // Update total amount
        }
    });

    // Update total amount display
    updateTotalAmountDisplay();
    // Update change display after total amount is updated
    updateChangeDisplay();
}

// Function to update the display of total amount (ensure this is not duplicated)
function updateTotalAmountDisplay() {
    const totalAmountDisplay = document.querySelector('.total-amount'); // Update selector to match your UI
    if (totalAmountDisplay) {
        totalAmountDisplay.value = `₱${totalAmount.toFixed(2)}`; // Set value of the input field
    }
}

// Function to handle payment input and update change display
function handlePaymentInput(paymentInputElement) {
    // Get payment amount from the input, ensuring it's numeric
    const rawInput = paymentInputElement.value.replace('₱', '').replace(',', '').trim();
    const parsedAmount = parseFloat(rawInput);
    
    // Ensure it's a valid positive number
    if (isNaN(parsedAmount) || parsedAmount < 0) {
        paymentAmount = 0; // Reset to zero if invalid
        console.error('Invalid payment amount:', rawInput); // Debug log
    } else {
        paymentAmount = parsedAmount; // Assign valid number
    }
    
    // Log the current payment amount for debugging
    console.log(`Current Payment Amount: ₱${paymentAmount.toFixed(2)}`);
    
    // Update the change display based on the current total
    updateChangeDisplay(); // This will update the change display
}

// Payment input event listener
const paymentInputElement = document.querySelector('.payment-input');
paymentInputElement.addEventListener('input', () => {
    handlePaymentInput(paymentInputElement);
});
