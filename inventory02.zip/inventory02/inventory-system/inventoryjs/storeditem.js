document.addEventListener("DOMContentLoaded", function() {
    fetchItems();
});

function fetchItems() {
    fetch('/get-items')  // Make sure the endpoint is correct for fetching items
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const items = data.items;
                const displayContainer = document.querySelector('.display-item');
                displayContainer.innerHTML = ''; // Clear the existing data

                // Loop through the items and create table rows
                items.forEach(item => {
                    const row = document.createElement('div');
                    row.classList.add('item-row');
                    row.setAttribute('data-item-id', item.id);  // Add data-item-id here
                    row.innerHTML = `
                        <div class="item-data">${item.itemname}</div>
                        <div class="item-data">${item.size || ' '}</div>
                        <div class="item-data">${item.price}</div>
                        <div class="item-data">${item.unit}</div>
                        <div class="item-data">${item.quantity}</div>
                        <div class="item-data">
                            <button onclick="deleteItem(${item.id})">Delete</button>
                        </div>
                    `;
                    displayContainer.appendChild(row);
                });
            } else {
                console.error('Failed to fetch items');
            }
        })
        .catch(error => {
            console.error('Error fetching items:', error);
        });
}

function deleteItem(itemId) {
    // Open IndexedDB and delete the item from there
    const request = indexedDB.open('InventoryDB', 3);
    request.onsuccess = function(event) {
        const db = event.target.result;
        const transaction = db.transaction(['items'], 'readwrite');
        const store = transaction.objectStore('items');
        const deleteRequest = store.delete(itemId);

        deleteRequest.onsuccess = function() {
            console.log('Item deleted from IndexedDB');

            // Delete the item from the backend (main database)
            fetch(`/delete-item/${itemId}`, {
                method: 'DELETE',
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Item deleted from backend database');
                    // Find and remove the row from the UI
                    const itemRow = document.querySelector(`.item-row[data-item-id="${itemId}"]`);
                    if (itemRow) {
                        itemRow.remove(); // Remove the row from the display
                    }
                    alert('Item successfully deleted');
                } else {
                    console.error('Failed to delete item from the backend');
                    alert('Failed to delete item from the backend');
                }
            })
            .catch(error => {
                console.error('Error deleting item from the backend:', error);
                alert('Error deleting item from the backend');
            });
        }; 

        deleteRequest.onerror = function(event) {
            console.error('Error deleting item from IndexedDB:', event.target.error);
        };
    };

    request.onerror = function(event) {
        console.error('Error opening IndexedDB:', event.target.error);
    };
}

function items() {
    const sale = document.querySelector('.item-container');
    if(sales) {
        sale.scrollIntoView({behavior: "smooth"})
    }
}
function sales() {
    const sale = document.querySelector('.sales-container');
    if(sales) {
        sale.scrollIntoView({behavior: "smooth"})
    }
}

function users() {
    const user = document.querySelector('.user-container');
    if(users) {
        user.scrollIntoView({behavior : "smooth"});
    }
}

function fetchPurchasedItems() {
    fetch('/get-purchased')
        .then(response => {
            if (!response.ok) {
                throw new Error(`Server error: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Successfully fetched purchased items:', data);
            displayPurchasedItems(data.purchasedData);
        })
        .catch(error => {
            console.error('Error fetching purchased items:', error);
            alert('An error occurred while fetching the purchased items.');
        });
}

function displayPurchasedItems(purchasedItems) {
    const container = document.querySelector('.purchased-display');

    // Check if the container exists
    if (!container) {
        console.error("Error: '.purchased-display' element not found.");
        return;  // Exit the function if the container is not found
    }

    container.innerHTML = '';  // Clear any existing content

    purchasedItems.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('good-item');

        const total = parseFloat(item.total) || 0;  // Default to 0 if it's not a valid number

        itemDiv.innerHTML = `       
            <div class="bought">${item.itemname}</div>
            <div class="bought">${item.size || ''}</div>
            <div class="bought">$${parseFloat(item.price).toFixed(2)}</div>
            <div class="bought">${item.unit || ''}</div>
            <div class="bought">${item.quantity}</div>
            <div class="bought">$${total.toFixed(2)}</div>
        `;

        // Append the itemDiv to the container
        container.appendChild(itemDiv);  
    });
}

document.addEventListener('DOMContentLoaded', () => {
    fetchPurchasedItems(); // This will fetch and display the data on page load
});

function fetchUserData() {
    fetch('/get-userdata')
    .then(response => {
        if(!response.ok) {
            throw new Error(`Server error: ${response.statusText}`);
        }
        return response.json();
    })  
    .then(data => {
        console.log('Successfully fetched use data.');
        displayuserdata(data.datausers);
    })
    .catch(error => {
        console.error('Error fetching purchased items:', error);
        alert('An error occurred while fetching the purchased items.');
    })
}

function displayuserdata(usersdata) {
    const container = document.querySelector('.user-display');

    if(!container) {
        console.error("Error: '.purchased-display' element not found.");
        return; 
    }

    container.innerHTML = '';

    usersdata.forEach(user => {
        const userDiv = document.createElement('div');
        userDiv.classList.add('data-user');

        userDiv.innerHTML = `
        <div class="data">${user.userfirstname}</div>
        <div class="data">${user.userlastname}</div>
        <div class="data">${user.role}</div>
        <div class="data">${user.date}</div>
        `;

        container.appendChild(userDiv);
    })
}

document.addEventListener('DOMContentLoaded', () => {
    fetchUserData();
})

function mainbck() {
    const userRole = localStorage.getItem("userRole"); 
    
    if (userRole !== 'owner') {
        alert("This button only works if you're logged in as an owner.");
    } else {
        window.location.href = '/inventory'; 
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const logoutButton = document.querySelector('.logout-button');
    const userRole = localStorage.getItem("userRole");

    if (userRole !== 'admin') {
        logoutButton.style.display = 'none'; // Hide the button for non-admins
    }
});

function adminLogout() {
    // Remove logged in status and user role from localStorage
    localStorage.removeItem("loggedIn");
    localStorage.removeItem("userRole");

    // Redirect the user to the inventory page
    window.location.href = '/inventory'; // Or any URL for your inventory page
}
