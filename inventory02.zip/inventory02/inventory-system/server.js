const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' })

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json({ limit: '10mb' }));
app.use(cors());

app.use('/inventorystyles', express.static(path.join(__dirname, 'inventorystyles')));
app.use('/pictures', express.static(path.join(__dirname, 'pictures')));
app.use('/inventoryjs', express.static(path.join(__dirname, 'inventoryjs')));

app.get('/inventory', (req, res) => {
    res.sendFile(path.join(__dirname, 'inventoryabiash.html'));
});

app.get('/item', (req, res) => {
    res.sendFile(path.join(__dirname, 'item.html'));
})

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'abiash' 
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to the database.');
});

let availableIds = []; 
let itemsData = [];  

app.post('/submit-item', upload.array('images'), (req, res) => {
    const { name, size, price, unit, quantity } = req.body;

    if (!name || !price || !unit || quantity === undefined) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    const parsedQuantity = parseInt(quantity, 10);
    
    if (isNaN(parsedQuantity) || parsedQuantity <= 0) {
        return res.status(400).json({ error: 'Invalid quantity' });
    }

    // Check if images exist in request
    if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'No files uploaded' });
    }

    const imagePaths = req.files.map(file => file.path); // Store image paths for frontend purposes, not DB

    // Check if item exists
    const checkSql = `
        SELECT * FROM item 
        WHERE itemname = ? 
        AND size = ? 
        AND price = ? 
        AND unit = ?;
    `;

    db.query(checkSql, [name, size, price, unit], (err, results) => {
        if (err) {
            console.error('Error checking item existence:', err);
            return res.status(500).json({ error: 'Failed to check item existence' });
        }

        if (results.length > 0) {
            // Item exists, update quantity
            const existingItem = results[0];
            const newQuantity = (existingItem.quantity || 0) + parsedQuantity;

            const updateSql = `UPDATE item SET quantity = ? WHERE id = ?`;
            db.query(updateSql, [newQuantity, existingItem.id], (err, result) => {
                if (err) {
                    console.error('Error updating item quantity:', err);
                    return res.status(500).json({ error: 'Failed to update item quantity' });
                }

                console.log('Item quantity updated in MySQL:', result);
                return res.json({ success: true, itemId: existingItem.id });
            });
        } else {
            // Item doesn't exist, insert as new item
            const insertSql = `
                INSERT INTO item (itemname, size, price, unit, quantity) 
                VALUES (?, ?, ?, ?, ?)
            `;
            const values = [name, size, price, unit, parsedQuantity];

            db.query(insertSql, values, (err, result) => {
                if (err) {
                    console.error('Error inserting item:', err);
                    return res.status(500).json({ error: 'Failed to store item' });
                }

                console.log('New item added to MySQL:', result);
                res.json({ success: true, itemId: result.insertId });
            });
        }
    });
});

app.post('/update-item-quantity', (req, res) => {
    const { itemId, quantity } = req.body;

    // Validate inputs
    if (!itemId || quantity === undefined) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    // Debug log to check the incoming data
    console.log(`Attempting to update item with ID: ${itemId}, New Quantity: ${quantity}`);

    // Update SQL query to set the new quantity in the database
    const updateSql = 'UPDATE item SET quantity = ? WHERE id = ?';
    db.query(updateSql, [quantity, itemId], (err, result) => {
        if (err) {
            console.error('Error updating item quantity:', err);
            return res.status(500).json({ error: 'Failed to update item quantity' });
        }

        // Check if any rows were actually updated
        if (result.affectedRows === 0) {
            console.log(`No rows updated. Item ID ${itemId} might not exist or is not matching.`);
            return res.status(404).json({ error: `Item with ID ${itemId} not found` });
        }

        console.log('Item quantity updated in MySQL:', result);
        res.json({ success: true });
    });
});

app.post('/submit-supply', upload.array('images'), (req, res) => {
    const { name, size, price, unit, quantity } = req.body;

    // Validate input
    if (!name || !price || !unit || quantity === undefined) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    // Parse quantity to ensure it's a number
    const quantityNum = parseInt(quantity, 10);  // Ensure quantity is a number

    if (isNaN(quantityNum) || quantityNum <= 0) {
        return res.status(400).json({ error: 'Invalid quantity' });
    }

    // Check if images exist in request
    if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'No files uploaded' });
    }

    const imagePaths = req.files.map(file => file.path); // Store image paths for frontend purposes, not DB

    // Check if supply exists
    const checkSql = `
        SELECT * FROM item 
        WHERE itemname = ? 
        AND (size IS NULL OR size = '') 
        AND price = ? 
        AND unit = ?;
    `;

    db.query(checkSql, [name, price, unit], (err, results) => {
        if (err) {
            console.error('Error checking supply existence:', err);
            return res.status(500).json({ error: 'Failed to check supply existence' });
        }

        if (results.length > 0) {
            // Supply exists, update quantity
            const existingSupply = results[0];
            const newQuantity = (existingSupply.quantity || 0) + quantityNum;

            const updateSql = `UPDATE item SET quantity = ? WHERE id = ?`;
            db.query(updateSql, [newQuantity, existingSupply.id], (err, result) => {
                if (err) {
                    console.error('Error updating supply quantity:', err);
                    return res.status(500).json({ error: 'Failed to update supply quantity' });
                }

                console.log('Supply quantity updated in MySQL:', result);
                return res.json({ success: true, itemId: existingSupply.id });
            });
        } else {
            // Supply doesn't exist, insert as new supply
            const insertSql = `INSERT INTO item (itemname, size, price, unit, quantity) VALUES (?, NULL, ?, ?, ?)`;
            const values = [name, price, unit, quantityNum];

            db.query(insertSql, values, (err, result) => {
                if (err) {
                    console.error('Error inserting supply:', err);
                    return res.status(500).json({ error: 'Failed to store supply' });
                }
                console.log('New supply added to MySQL:', result);
                res.json({ success: true, itemId: result.insertId });
            });
        }
    });
});

app.post('/submit-purchased', (req, res) => {
    const purchasedItems = req.body.items;  // Extract purchased items
    console.log("Received purchased items:", purchasedItems);

    if (!purchasedItems || purchasedItems.length === 0) {
        console.error("No items to insert");
        return res.status(400).json({ message: 'No items to insert.' });
    }

    const values = purchasedItems.map(item => [
        item.item_id,        
        item.itemname,      
        item.size || '',     
        item.price,          
        item.unit,           
        item.quantity,     
        item.total        
    ]);

    const query = 'INSERT INTO purchased (item_id, itemname, size, price, unit, quantity, total) VALUES ?';

    db.query(query, [values], (error, results) => {
        if (error) {
            console.error('SQL error:', error);
            return res.status(500).json({ message: 'Error inserting purchased items.' });
        } else {
            console.log('Successfully inserted purchased items');
            res.status(200).json({ message: 'Purchased items successfully added.' });
        }
    });
});

app.post('/submit-form', (req, res) => {
    const { 
        description, 
        date1, quantity1, cost, 
        date2, invNum, pAddress, quantity2, price, amount, 
        hold 
    } = req.body;

    const sql = `INSERT INTO newproducts (description, date1, quantity1, cost, date2, invNum, pAddress, quantity2, price, amount, hold) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
            
    db.query(sql, [description, date1, quantity1, cost, date2, invNum, pAddress, quantity2, price, amount, hold], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        
        // Fetch the last inserted product and return the details
        const insertedProduct = {
            id: result.insertId, // Assuming `insertId` gives the last inserted ID in MySQL
            description, 
            date1, 
            quantity1, 
            cost, 
            date2, 
            invNum, 
            pAddress, 
            quantity2, 
            price, 
            amount, 
            hold
        };

        res.status(200).json(insertedProduct);  // Return the inserted product details
    });
});

app.post('/submitdata-form', (req, res) => {
    const { userfirstname, userlastname, role, abiashusername, abiashpassword } = req.body;

    // Ensure all required fields are present
    if (!userfirstname || !userlastname || !abiashusername || !abiashpassword || !role) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    const currentDate = new Date();  // Capture current date

    // SQL to insert data into the table with the dynamic role
    const sql2 = `INSERT INTO users (userfirstname, userlastname, role, abiashusername, abiashpassword, date)
                  VALUES (?, ?, ?, ?, ?, ?)`;  // Use the column names from your table
    
    // Execute the SQL query with the provided data
    db.query(sql2, [userfirstname, userlastname, role, abiashusername, abiashpassword, currentDate], (err, result) => {
        if (err) {
            console.error('Database insertion error:', err); 
            return res.status(500).json({ error: 'Database error', details: err });
        }
        res.send('Login successful!');
    });
});

app.get('/get-purchased', (req, res) => {
    const query = 'SELECT * FROM purchased ORDER BY id DESC';
    
    db.query(query, (error, results) => {
        if (error) {
            console.error('Error fetching purchased items:', error);
            return res.status(500).json({ message: 'Error fetching purchased items.' });
        } else {
            // Get the total_amount from the first row
            const totalAmount = results.length > 0 ? results[0].total_amount : 0;

            res.status(200).json({
                purchasedData: results,
                totalAmount: totalAmount
            });
        }
    });
});

// Endpoint to get users' data from the database
app.get('/get-userdata', (req, res) => {
    const sql = 'SELECT userfirstname, userlastname, role, abiashusername, date FROM users';
    
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            return res.status(500).json({ error: 'Database error', details: err });
        } else {
            res.status(200).json ({
                datausers: results
            })
        }
    });
});


app.get('/get-items', (req, res) => {
    const query = 'SELECT * FROM item';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching items:', err);
            res.status(500).json({ success: false, message: 'Error fetching items' });
            return;
        }
        res.json({ success: true, items: results });
    });
});

app.delete('/delete-item/:id', (req, res) => {
    const itemId = req.params.id;
    const query = 'DELETE FROM item WHERE id = ?';

    db.query(query, [itemId], (err, results) => {
        if (err) {
            console.error('Error deleting item:', err);
            res.status(500).json({ success: false, message: 'Error deleting item' });
            return;
        }

        // Remove the item from itemsData
        itemsData = itemsData.filter(item => item.id !== itemId);  // Filter out the deleted item

        res.json({ success: true });
    });
});


app.get('/get-products', (req, res) => {
    const sql = 'SELECT * FROM newproducts';
    db.query(sql, (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database query error' });
        }
        res.setHeader('Content-Type', 'application/json');
        res.json(results);
    });
});

app.delete('/delete-product/:id', (req, res) => {
    const productId = req.params.id;
    const sql = 'DELETE FROM newproducts WHERE id = ?';

    db.query(sql, [productId], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }

        availableIds.push(productId);
        res.send('Product deleted successfully!');
    });
});

app.put('/edit-product/:id', (req, res) => {
    const productId = req.params.id;
    const { description, date1, quantity1, cost, date2, invNum, pAddress, quantity2, price, amount, hold } = req.body;

    const sql = `UPDATE newproducts SET description = ?, date1 = ?, quantity1 = ?, cost = ?, date2 = ?, invNum = ?, pAddress = ?, quantity2 = ?, price = ?, amount = ?, hold = ? WHERE id = ?`;

    db.query(sql, [description, date1, quantity1, cost, date2, invNum, pAddress, quantity2, price, amount, hold, productId], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.send('Product updated successfully!');
    });
});

// Express.js route to handle item deletion
app.delete('/delete-item/:id', (req, res) => {
    const itemId = req.params.id;
    
    // Perform deletion from your main database (e.g., SQL, MongoDB)
    db.collection('items').deleteOne({ id: itemId })
        .then(result => {
            if (result.deletedCount > 0) {
                res.json({ success: true });
            } else {
                res.json({ success: false, message: 'Item not found' });
            }
        })
        .catch(error => {
            console.error('Error deleting item from database:', error);
            res.status(500).json({ success: false, message: 'Server error' });
        });
});


app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
